//
//  Configs.swift
//  App14
//
//  Created by Sakib Miazi on 6/14/23.
//

import Foundation
class Configs{
    static let placeIdentifier = "placeIdentifier"
    static let searchTableViewID = "searchTableViewID"
}
