//
//  ProgressSpinnerDelegate.swift
//  pilly
//
//  Created by Belen Tesfaye on 11/24/24.
//

import Foundation
protocol ProgressSpinnerDelegate{
    func showActivityIndicator()
    func hideActivityIndicator()
}
