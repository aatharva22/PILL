//
//  Utilities.swift
//  pilly
//
//  Created by Samantha Ranjo on 10/27/24.
//

import Foundation

class Utilities {
    static let times = ["Morning", "Afternoon", "Evening"]
}
